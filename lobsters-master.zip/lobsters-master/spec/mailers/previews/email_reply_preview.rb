# typed: false

# Preview all emails at http://localhost:3000/rails/mailers/email_reply
class EmailReplyPreview < ActionMailer::Preview
end
