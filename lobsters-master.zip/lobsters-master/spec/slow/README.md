Tests in this directory do not run as part of the regular test suite with
`bundle exec rspec`. They are excluded by config.exclude
