# typed: false

Rack::MiniProfiler.config.disable_caching = false
Rack::MiniProfiler.config.position = "bottom-left"
