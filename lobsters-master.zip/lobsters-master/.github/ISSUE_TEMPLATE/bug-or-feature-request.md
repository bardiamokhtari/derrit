---
name: Bug or feature request
about: All-purpose issue
title: ''
labels: ''
assignees: ''

---

<!--
Bug reports: It's really helpful to know if you were logged in, and if you can include screenshots.

Feature requests: Please discuss them in the chat room or a meta thread before posting. We're deliberate about community design, so this helps you learn if we've considered similar ideas and build consensus around your idea.

I (@pushcx) try to timebox non-urgent Lobsters maintenance to the scheduled office hours streams (https://push.cx/stream), so it may take me a couple days to respond. If you don't want your issue or PR reviewed on a stream, say so and I won't.
-->
