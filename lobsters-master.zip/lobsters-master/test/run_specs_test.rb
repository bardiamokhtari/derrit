# typed: false

require "rspec/core"
RSpec::Core::Runner.run(["spec"])
