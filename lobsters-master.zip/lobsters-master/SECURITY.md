# Security Policy

## Supported Versions

This repo exists to public the source to https://lobste.rs

While we occasionally answer questions, we don't have a formal support
policy for sites using the codebase.


## Reporting a Vulnerability

Please email peter@push.cx. I'll try to respond promptly.
If you've found an issue, I'll help ensure you get credit for it.
